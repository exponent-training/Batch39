package com.springmvc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.model.Student;


@Repository
public class StudentRepoImpl  implements StudentRepo{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public void saveStudent(Student s) {
		System.out.println("Student repo layer");
		
		System.out.println(s);
		
		Session session=sf.openSession();
		session.save(s);
		session.beginTransaction().commit();
		
		System.out.println("Successfully saved!!");
	}

	@Override
	public List<Student> getAllData() {
		
		System.out.println("Get all Data repo layer");
		
		Session session=sf.openSession();
		
		Query<Student> query=session.createQuery("from Student");
		List<Student> list=query.getResultList();
		System.out.println("data : "+list);
		return list;
	}

	@Override
	public void deleteData(int sid) {
		System.out.println("Delete Data in dao : "+sid);
		
		Session session=sf.openSession();
		Student s=session.get(Student.class, sid);
		
		session.delete(s);
		session.beginTransaction().commit();
		System.out.println("Deleted successfully");
	}

}
