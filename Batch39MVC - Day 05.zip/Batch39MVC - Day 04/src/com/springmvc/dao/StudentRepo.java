package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.Student;

public interface StudentRepo {
	
	public void saveStudent(Student s);
	
	public List<Student> getAllData();
	
	public void deleteData(int sid);

}
