package com.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.Student;
import com.springmvc.service.StudentService;

@Controller
public class MyController {

	@Autowired
	private StudentService ss;
	
	@RequestMapping(value = "log")
	public String logMethod(@RequestParam String user, @RequestParam String pass,Model model) {

		System.out.println("Login method ");
		System.out.println("User name : " + user);
		System.out.println("Password : " + pass);
		
		if(user.equals("admin") && pass.equals("admin@123")) {
			System.out.println("login successfully ");
			
			List<Student> list=ss.getAllStudent();
			model.addAttribute("slist",list);
			model.addAttribute("msg","Login successfully");
			return "details";
		}else {
			
			model.addAttribute("msg","Inavlid Username and password");
			return "login";
		}

	}

	@RequestMapping(value = "reg")
	public String registerMethod(@ModelAttribute Student stu, Model model) {

		System.out.println("register method ");
		System.out.println(stu);

		ss.addStudent(stu);
		
		model.addAttribute("stu", stu);

		return "success";

	}
	
	@RequestMapping(value="del")
	public String deleteStudent(@RequestParam int sid,Model m) {
		
		System.out.println("Delete Student in controller : "+sid);
		
		ss.deleteStu(sid);
		
		m.addAttribute("stu", "Successfully Deleted!!");
		return "success";
	}
	
	

}
