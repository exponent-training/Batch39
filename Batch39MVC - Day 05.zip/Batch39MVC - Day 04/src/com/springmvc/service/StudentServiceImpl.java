package com.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.dao.StudentRepo;
import com.springmvc.model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepo repo;

	@Override
	public void addStudent(Student s) {
		
		System.out.println("Student Service layer");
		System.out.println(s);
		
		repo.saveStudent(s);
		
	}

	@Override
	public List<Student> getAllStudent() {
		System.out.println("Get All stu Service Layer");
		
		return repo.getAllData();
	}

	@Override
	public void deleteStu(int sid) {
		System.out.println("Student delete service layer !! : "+sid);
		repo.deleteData(sid);
	}

}
