package com.example;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface StudentRepo extends JpaRepository<Student, Integer>{
	
	public Student findBySname(String sname);
	
	public List<Student> findByMarksGreaterThan(double marks);
	
	@Query(value = "select marks from Student where sname=:name")//hql jpql
	public double abc(String name);

}
