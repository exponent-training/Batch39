package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DataJpaExApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(DataJpaExApplication.class, args);
		
		StudentRepo stuRepo=context.getBean(StudentRepo.class);
		
//		System.out.println(stuRepo.getClass());
		
		Student s=new Student(2, "abc", 78.46);
		Student s1=new Student(3, "rtyu", 12.46);
		Student s2=new Student(33, "xyz", 98.46);
		
		List<Integer > lit= new ArrayList<Integer>();
		lit.add(2);
		lit.add(1);
		lit.add(4);
		
		
		
//		stuRepo.save(s1);//UPSERT
//		stuRepo.saveAll(lit);
		
//		System.out.println(stuRepo.findById(4));
//		System.out.println(stuRepo.findAll());
//		System.out.println(stuRepo.findAllById(lit));
		
//		System.out.println(stuRepo.existsById(11));
//		System.out.println(stuRepo.count());
		
//		stuRepo.delete(s);
//		stuRepo.deleteAll();
//		stuRepo.deleteAllById(list);
//		stuRepo.deleteAll(list);
//		stuRepo.deleteById(id);
		
//		System.out.println(stuRepo.findBySname("abc"));
//		System.out.println(stuRepo.findByMarksGreaterThan(35.00));
		System.out.println(stuRepo.abc("abc"));
		
		
	}

}
