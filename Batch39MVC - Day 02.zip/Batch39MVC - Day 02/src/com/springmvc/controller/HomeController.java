package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.Student;

@Controller
public class HomeController {
	
	@RequestMapping(value="/log")
	public String loginMethod(@RequestParam String username,@RequestParam ("pass") String password) {
		
		System.out.println("Debug : Login Method Called");
		System.out.println("Info : Username : "+username);
		System.out.println("Info : Password : "+password);
		
		return "success";
	}
	
	@RequestMapping(value="reg")
	public String registerMethod(@ModelAttribute Student s) {
		System.out.println("Debug : Regsiter Method");
//		System.out.println("Info : sid : "+sid);
//		System.out.println("Info : sname : "+sname);
//		Student s= new Student();
//		s.setSid(sid);
//		s.setSname(sname);
		
		System.out.println("Info : "+s);
		
		return "success";
	}
	

}
