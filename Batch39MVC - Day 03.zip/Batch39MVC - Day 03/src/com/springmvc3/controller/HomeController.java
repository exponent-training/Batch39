package com.springmvc3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.springmvc3.model.Student;

@Controller
public class HomeController {
	
	@RequestMapping(value="log")
	public String loginMethod(@RequestParam String user,@RequestParam ("pass")String password) {
		System.out.println("Debug : Login Method in Controller");
		
		System.out.println("Info : Username : "+user);
		System.out.println("Info : Password : "+password);
		
		return "success";//model and view
	}
	
	
	@RequestMapping(value="reg")
	public String registerMethod(@ModelAttribute Student s,Model model) {
		System.out.println("Debug : register Method in Controller");
		
		System.out.println("Info : "+s);
		
		model.addAttribute("studentObj", 55);
		
		return "success";
	}
	
	

}
