package com.springmvc.dao;

import com.springmvc.model.Student;

public interface StudentRepo {
	
	public void saveStudent(Student s);

}
