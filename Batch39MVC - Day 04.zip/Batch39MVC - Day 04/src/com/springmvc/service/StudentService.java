package com.springmvc.service;

import com.springmvc.model.Student;

public interface StudentService {
	
	public void addStudent(Student s);

}
