package com.springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.dao.StudentRepo;
import com.springmvc.model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepo repo;

	@Override
	public void addStudent(Student s) {
		
		System.out.println("Student Service layer");
		System.out.println(s);
		
		repo.saveStudent(s);
		
	}

}
