package com.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.Student;
import com.springmvc.service.StudentService;

@Controller
public class MyController {

	@Autowired
	private StudentService ss;
	
	@RequestMapping(value = "log")
	public String logMethod(@RequestParam String user, @RequestParam String pass) {

		System.out.println("Login method ");
		System.out.println("User name : " + user);
		System.out.println("Password : " + pass);

		return "success";

	}

	@RequestMapping(value = "reg")
	public String registerMethod(@ModelAttribute Student stu, Model model) {

		System.out.println("register method ");
		System.out.println(stu);

		ss.addStudent(stu);
		
		model.addAttribute("stu", stu);

		return "success";

	}
	
	

}
