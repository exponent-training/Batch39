package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
//	@RequestMapping(value="/reg")
	public String m1() {
		System.out.println("M1 called!!");
		return "success";
	}
	
	
	@RequestMapping(value="/update")
	public String m2() {
		System.out.println("M1 called!!");
		return "success";
	}
	

}
