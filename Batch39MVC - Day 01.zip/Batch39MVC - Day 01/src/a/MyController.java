package a;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@RequestMapping(value="/reg")
	public String m1() {
		System.out.println("M1 called!!");
		return "success";
	}

}
