package com.example.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@Value(value = "${myApplication}")
	private String property;

	@RequestMapping(value = "/")
	public String start() {

		System.out.println("Start method called !!");
		System.out.println(property);//maiApp

		return "index";//view

	}

}
