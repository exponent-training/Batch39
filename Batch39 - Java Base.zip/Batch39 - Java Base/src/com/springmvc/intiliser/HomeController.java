package com.springmvc.intiliser;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping(value="/")
	public String start() {
		System.out.println("App started");
		return "index";
	}
	
}
